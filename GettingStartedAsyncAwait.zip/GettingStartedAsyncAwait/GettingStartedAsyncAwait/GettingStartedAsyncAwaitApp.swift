//
//  GettingStartedAsyncAwaitApp.swift
//  GettingStartedAsyncAwait
//
//  Created by Mohammad Azam on 7/9/21.
//

import SwiftUI

@main
struct GettingStartedAsyncAwaitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
